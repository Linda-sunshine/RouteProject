package structures;

public class _Pair {
	int m_d1ID;
	int m_d2ID;
	
	public _Pair(){
		m_d1ID = 0;
		m_d2ID = 0;
	}
	
	public _Pair(int d1, int d2){
		m_d1ID = d1;
		m_d2ID = d2;
	}
}
